package clock;

public enum ClockState {
    FETCH,
    MEMORY
}
