package memory;

public class Data extends Word {

    public Data() {
        super();
    }

    public Data(int decimalContent){
        super(decimalContent);
    }

}
