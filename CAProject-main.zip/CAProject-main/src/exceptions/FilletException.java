package exceptions;

public class FilletException extends RuntimeException {

	public FilletException() {
		super();
	}

	public FilletException(String message) {
		super(message);
	}

}
